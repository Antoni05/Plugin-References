<?php

namespace Antoni\Nicow;

use Antoni\Entities\Cow;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\level\sound\AnvilBreakSound;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;


class Main extends PluginBase implements Listener
{

    public function onEnable()
    {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onCommand(CommandSender $sender, Command $cmd, String $label, array $args): bool
    {
        if ($cmd->getName() === "npc") {
            if (!$args) {
                $sender->sendMessage("Usage: /npc <name>");
                return true;
            }
            switch ($args[0]) {
                case "cow":
                    $this->spawnThing($sender, $args[0], true);
                    break;
            }
        }
        return true;
    }

    public function spawnThing(Player $player, String $name, bool $type)
    {
        $nbt = Entity::createBaseNBT($player->asVector3());
        $npc = new Cow($player->getLevel(), $nbt);
        $npc->setNameTag($name);
        $npc->setNameTagVisible($type);
        $npc->spawnTo($player);
    }

    public function onSlap(EntityDamageByEntityEvent $ee) {
        $target = $ee->getEntity();
        $player = $ee->getDamager();

        if($target instanceof Cow) {
            $player->getLevel()->addSound(new AnvilBreakSound($player));
        }
    }

}
