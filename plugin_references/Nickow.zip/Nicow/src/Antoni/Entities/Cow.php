<?php

namespace Antoni\Entities;

use pocketmine\entity\Ageable;
use pocketmine\entity\Creature;
use pocketmine\entity\NPC;

class Cow extends Creature implements NPC {

    public const NETWORK_ID = self::COW;

    public $width = 0.9;
    public $height = 1.4;

    public function getName(): string {
        return "Cow";
        // TODO: Implement getName() method.
    }

}